package com.cleartax.assessment

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class PixxelApplicationTests {

    @Test
    fun contextLoads() {
    }

}
