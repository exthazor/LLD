package com.cleartax.assessment.models

enum class SinkType {
    STDOUT
}