package com.cleartax.assessment.models

enum class LoggerType {
    SYNC, ASYNC
}